int main(){
    int a,s,d,f,g,h,j,k,l;
}

int q,w,e,r,t,a,s,d;

void test(){
    int q,w,e,r,t,z;
}
