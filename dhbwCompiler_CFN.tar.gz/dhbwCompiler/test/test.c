void test(int i, int a, int p);

int main(){
    int a,s,d,f;
    int j[4];
    int e[6];
}

int m[2];

int q,w,e,r,t,a,s,d;

void test(int i, int a, int p){
    int q,w,e,r,t,z;
}
